
public class sample {

}
