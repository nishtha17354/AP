package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;

import java.io.IOException;

public class Cart


{
    @FXML
    private Label bleh1,bleh2;

    public void pressButton1(ActionEvent event) throws IOException
    {
//
//        EndUserItem.pressButton1(event);
//        bleh1.setText(itemName1);


    }

}
